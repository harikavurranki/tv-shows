<template>
  <div>
    <h1 class="notfound">Page Not Found</h1>
  </div>
</template>
<script>
export default {
  name: 'PageNotFound'
}
</script>
