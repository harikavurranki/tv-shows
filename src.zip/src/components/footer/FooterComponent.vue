<template>
  <div class="headerbg pt3 pb3">
    <div class="container footerclass">
      2020 © Shows hub. All rights reserved.
    </div>
  </div>
</template>
<script>
export default {
  name: 'FooterComponent',
  data () {
    return {
    }
  },
  methods: {
  },
  created () {
  }
}
</script>
<style>
</style>
